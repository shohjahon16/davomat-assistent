# Davomat — o'rnatish qo'llanmasi

Ustoz va o'quvchilar kelganda/ketganda selfi olib yuboradi → rasm Google Drive'ga, vaqt va ism Google Sheets'ga yoziladi.
Siz uchun maxfiy PIN bilan "Hisobot" bo'limi bor.

## Fayllar

| Fayl | Nima uchun |
|---|---|
| `index.html` | Saytning o'zi (dizayn + mantiq). Sozlamalar tepasida `CONFIG` ichida |
| `apps-script/Code.gs` | Google Sheets/Drive bilan ishlovchi server kodi |
| `manifest.webmanifest`, `sw.js`, `icons/` | Telefonga ilova sifatida o'rnatish (PWA), oflayn ochilish |

## 1-qadam. Google Sheets + Apps Script (5 daqiqa)

1. [sheets.new](https://sheets.new) — yangi jadval oching, nomini "Davomat" qiling.
2. **Kengaytmalar → Apps Script** ni bosing.
3. Ochilgan muharrirdagi hamma narsani o'chirib, `apps-script/Code.gs` ichidagini joylashtiring.
4. Yuqoridagi `CODE` (markaz kodi) va `ADMIN_PIN` (faqat sizga) ni o'zgartiring.
5. Yuqoridagi funksiyalar ro'yxatidan **`setup`** ni tanlab **Ishga tushirish** bosing → Google ruxsat so'raydi (Sheets va Drive) → ruxsat bering.
   Shundan so'ng jadvalda "Davomat" va "Odamlar" varaqlari, Drive'da "Davomat rasmlari" papkasi paydo bo'ladi.
6. **Deploy → New deployment → ⚙ → Web app**
   - Execute as: **Me**
   - Who has access: **Anyone**
   - **Deploy** → chiqqan **Web app URL** ni nusxalang.

> Kodni keyinroq o'zgartirsangiz: Deploy → Manage deployments → ✏ → Version: **New version** → Deploy.

## 2-qadam. Saytni sozlash

`index.html` ni matn muharririda ochib, tepadagi blokni to'ldiring:

```js
const CONFIG = {
  CENTER_NAME: "Sizning markazingiz nomi",
  API_URL: "https://script.google.com/macros/s/.../exec"
};
```

## 3-qadam. Internetga joylash (bepul, HTTPS shart!)

Kamera faqat HTTPS saytlarda ishlaydi. Eng oson yo'llar:

- **Netlify Drop**: [app.netlify.com/drop](https://app.netlify.com/drop) — butun papkani (zip emas, ochilgan papka) sudrab tashlang.
- **Cloudflare Pages** yoki **GitHub Pages** — ham bepul.

Natijada `https://...netlify.app` kabi manzil olasiz.

## 4-qadam. Telefonga ilova sifatida o'rnatish (Android)

1. Android'da **Chrome** orqali saytni oching.
2. ⚙ **Sozlamalar** tugmasi → **"Ilovani telefonga o'rnatish"** (yoki Chrome menyusi ⋮ → *Ilovani o'rnatish*).
3. Bosh ekranda "Davomat" ikonkasi paydo bo'ladi — oddiy ilova kabi to'liq ekranda ochiladi.
4. Birinchi marta: ⚙ → **Markaz kodi** ni kiriting (bir marta, qurilmada saqlanadi).

iPhone: Safari → Ulashish → **Bosh ekranga qo'shish**.

### Haqiqiy APK fayl kerak bo'lsa
[pwabuilder.com](https://www.pwabuilder.com) ga sayt manzilingizni kiriting → **Package for stores → Android** → APK/AAB yuklab oling. Uni to'g'ridan-to'g'ri o'quvchi/ustozlarga yuborib o'rnatish mumkin (Play Market shart emas).

## Qanday ishlaydi

- Ustoz/o'quvchi: rolni tanlaydi → ismini yozadi → **Keldim/Ketdim** → selfi → **Yuborish**.
- Jadvalga yoziladi: **Sana, Vaqt, Ism, Rol, Holat, Rasm (havola), Qurilma**. Vaqt **server vaqti** (Toshkent) — telefon soatini o'zgartirib aldab bo'lmaydi.
- Rasmlar Drive'da kun bo'yicha papkalarda: `Davomat rasmlari/2026-11-01/...`. Faqat sizga ko'rinadi.
- **Internet yo'q bo'lsa**: yozuv telefonda saqlanadi va ulanganda o'zi yuboriladi.
- **Hisobot** (pastdagi tugma) → PIN → bugun kimlar kelgani, nechtasi hozir ichkarida, rasmlar.
- **"Odamlar" varag'i** (ixtiyoriy): ism va rolni kiritib qo'ysangiz, yozishda ismlar tavsiya qilinadi — imlo xatolari kamayadi.
- Bitta planshet eshik oldida tursa ham bo'ladi: yuborgandan 8 soniyadan keyin forma o'zi tozalanadi.

## Xavfsizlik va maxfiylik

- **Markaz kodi**ni faqat o'zingizning odamlaringizga bering; kodsiz hech kim yoza olmaydi. Kod tarqalib ketsa — `Code.gs` da o'zgartirib, yangi versiya deploy qiling.
- Rasmlar sukut bo'yicha yopiq (`PUBLIC_PHOTOS: false`).
- O'quvchilar (ayniqsa voyaga yetmaganlar) rasmga olinishi haqida ota-onalarni oldindan xabardor qiling va ularning roziligini oling.

## Muammolar

| Muammo | Yechim |
|---|---|
| "Kamera uchun HTTPS kerak" | Saytni `https://` manzildan oching (Netlify/Cloudflare) |
| "Markaz kodi noto'g'ri" | ⚙ da kodni `Code.gs` dagi `CODE` bilan bir xil kiriting |
| "Serverga ulanib bo'lmadi" | Deploy: *Who has access = Anyone* ekanini va `API_URL` oxiri `/exec` ekanini tekshiring |
| Kod o'zgartirdim, ishlamayapti | *Manage deployments → New version* qiling |
