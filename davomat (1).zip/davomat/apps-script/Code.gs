/**
 * DAVOMAT — Google Apps Script (Sheets + Drive)
 *
 * Bu skript Google Sheets jadvalingizga BOG'LANGAN bo'lishi kerak
 * (Sheets → Kengaytmalar → Apps Script).
 *
 * 1) Pastdagi CODE va ADMIN_PIN ni o'zgartiring.
 * 2) "setup" funksiyasini bir marta ishga tushiring (ruxsat bering).
 * 3) Deploy → New deployment → Web app
 *      Execute as: Me
 *      Who has access: Anyone
 * 4) Chiqqan "Web app URL" ni index.html dagi CONFIG.API_URL ga qo'ying.
 *
 * Kodni keyin o'zgartirsangiz: Deploy → Manage deployments → Edit → New version.
 */

const CONFIG = {
  CODE: "markaz2026",          // O'quvchi/ustozlarga beriladigan "markaz kodi"
  ADMIN_PIN: "7788",           // Faqat sizga: hisobotni ochish uchun
  SHEET_NAME: "Davomat",       // Davomat yoziladigan varaq
  PEOPLE_SHEET: "Odamlar",     // Ixtiyoriy: A=Ism, B=Rol (Ustoz / O'quvchi) — ismlar ro'yxati
  FOLDER_NAME: "Davomat rasmlari",
  TZ: "Asia/Tashkent",
  MAX_PHOTO_BYTES: 1500000,
  PUBLIC_PHOTOS: false         // true bo'lsa — rasmlar havola orqali hamma uchun ochiladi (tavsiya etilmaydi)
};

const ROLE_LABEL = { ustoz: "Ustoz", oquvchi: "O'quvchi" };
const TYPE_LABEL = { keldi: "Keldi", ketdi: "Ketdi" };
const HEADERS = ["Sana", "Vaqt", "Ism", "Rol", "Holat", "Rasm", "Qurilma", "FileId"];

/* ------------------------------------------------------------------ */

function setup() {
  getSheet_();
  getRootFolder_();
  Logger.log("Tayyor. Endi Deploy → New deployment → Web app qiling.");
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    const d = JSON.parse(e.postData.contents);

    if (!safeEq_(d.code, CONFIG.CODE)) return out_({ ok: false, error: "Markaz kodi noto'g'ri" });

    const name = String(d.name || "").replace(/\s+/g, " ").trim().slice(0, 60);
    const role = d.role === "ustoz" ? "ustoz" : "oquvchi";
    const type = d.type === "ketdi" ? "ketdi" : "keldi";
    if (name.length < 2) return out_({ ok: false, error: "Ism kiritilmagan" });
    if (!d.photo) return out_({ ok: false, error: "Rasm yo'q" });

    const bytes = Utilities.base64Decode(d.photo);
    if (bytes.length > CONFIG.MAX_PHOTO_BYTES) return out_({ ok: false, error: "Rasm juda katta" });

    // Vaqt: server vaqti. Oflayn yuborilganlar uchun qurilma vaqti (24 soatdan oshmasa).
    let when = new Date();
    let offline = false;
    if (d.queued && d.clientTs) {
      const t = new Date(Number(d.clientTs));
      if (!isNaN(t) && Math.abs(when - t) < 24 * 3600 * 1000 && t <= when) { when = t; offline = true; }
    }
    const date = Utilities.formatDate(when, CONFIG.TZ, "yyyy-MM-dd");
    const time = Utilities.formatDate(when, CONFIG.TZ, "HH:mm:ss");

    // Rasmni Drive'ga saqlash: "Davomat rasmlari/yyyy-MM-dd/"
    const dayFolder = getOrCreate_(getRootFolder_(), date);
    const safeName = name.replace(/[^\p{L}\p{N}]+/gu, "_");
    const fileName = time.replace(/:/g, "-") + "_" + ROLE_LABEL[role] + "_" + safeName + "_" + TYPE_LABEL[type] + ".jpg";
    const file = dayFolder.createFile(Utilities.newBlob(bytes, "image/jpeg", fileName));
    if (CONFIG.PUBLIC_PHOTOS) file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    const url = file.getUrl();

    // Sheets'ga yozish
    const sh = getSheet_();
    const row = sh.getLastRow() + 1;
    sh.getRange(row, 1, 1, 2).setNumberFormat("@").setValues([[date, time]]);
    sh.getRange(row, 3, 1, 3).setValues([[name, ROLE_LABEL[role], TYPE_LABEL[type]]]);
    sh.getRange(row, 6).setFormula('=HYPERLINK("' + url + '","Rasm")');
    sh.getRange(row, 7).setValue(String(d.device || "").slice(0, 40) + (offline ? " (oflayn)" : ""));
    sh.getRange(row, 8).setValue(file.getId());

    // Holatga qarab rang berish
    sh.getRange(row, 5).setBackground(type === "keldi" ? "#d9f7e8" : "#fff0d6");

    return out_({ ok: true, date: date, time: time });
  } catch (err) {
    return out_({ ok: false, error: "Server xatosi: " + err, retry: true });
  } finally {
    try { lock.releaseLock(); } catch (e2) {}
  }
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  try {
    if (p.action === "ping") {
      return safeEq_(p.code, CONFIG.CODE) ? out_({ ok: true }) : out_({ ok: false, error: "Markaz kodi noto'g'ri" });
    }
    if (p.action === "people") {
      if (!safeEq_(p.code, CONFIG.CODE)) return out_({ ok: false, error: "Markaz kodi noto'g'ri" });
      return out_({ ok: true, people: getPeople_() });
    }
    if (p.action === "today") {
      if (!safeEq_(p.pin, CONFIG.ADMIN_PIN)) return out_({ ok: false, error: "PIN noto'g'ri" });
      return out_(getToday_());
    }
    return out_({ ok: true, service: "davomat" });
  } catch (err) {
    return out_({ ok: false, error: "Server xatosi: " + err });
  }
}

/* ------------------------------------------------------------------ */

function getToday_() {
  const sh = getSheet_();
  const today = Utilities.formatDate(new Date(), CONFIG.TZ, "yyyy-MM-dd");
  const last = sh.getLastRow();
  const rows = [];
  if (last >= 2) {
    const start = Math.max(2, last - 499);
    const vals = sh.getRange(start, 1, last - start + 1, 8).getValues();
    vals.forEach(function (r) {
      let date = r[0], time = r[1];
      if (date instanceof Date) date = Utilities.formatDate(date, CONFIG.TZ, "yyyy-MM-dd");
      if (time instanceof Date) time = Utilities.formatDate(time, CONFIG.TZ, "HH:mm:ss");
      if (String(date) !== today) return;
      rows.push({
        time: String(time),
        name: String(r[2]),
        role: r[3] === "Ustoz" ? "ustoz" : "oquvchi",
        type: r[4] === "Ketdi" ? "ketdi" : "keldi",
        photo: r[7] ? "https://drive.google.com/file/d/" + r[7] + "/view" : ""
      });
    });
  }
  rows.sort(function (a, b) { return a.time < b.time ? -1 : a.time > b.time ? 1 : 0; });
  return { ok: true, date: today, rows: rows, sheetUrl: SpreadsheetApp.getActiveSpreadsheet().getUrl() };
}

function getPeople_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName(CONFIG.PEOPLE_SHEET);
  if (!sh || sh.getLastRow() < 1) return [];
  const vals = sh.getRange(1, 1, sh.getLastRow(), 2).getValues();
  const out = [];
  vals.forEach(function (r) {
    const name = String(r[0] || "").trim();
    if (!name || /^(ism|name)$/i.test(name)) return;
    const role = /ustoz|teacher|o'qituvchi/i.test(String(r[1])) ? "ustoz" : "oquvchi";
    out.push({ name: name, role: role });
  });
  return out;
}

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(CONFIG.SHEET_NAME);
  if (!sh) sh = ss.insertSheet(CONFIG.SHEET_NAME);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS])
      .setFontWeight("bold").setFontColor("#ffffff").setBackground("#4f46e5");
    sh.setFrozenRows(1);
    sh.setColumnWidths(1, 2, 100);
    sh.setColumnWidth(3, 220);
    sh.setColumnWidths(4, 2, 100);
    sh.hideColumns(8);
  }
  if (!ss.getSheetByName(CONFIG.PEOPLE_SHEET)) {
    const p = ss.insertSheet(CONFIG.PEOPLE_SHEET);
    p.getRange(1, 1, 1, 2).setValues([["Ism", "Rol"]]).setFontWeight("bold");
    p.getRange(2, 1, 2, 2).setValues([["Namuna Ustoz", "Ustoz"], ["Namuna O'quvchi", "O'quvchi"]]);
  }
  return sh;
}

function getRootFolder_() {
  const it = DriveApp.getFoldersByName(CONFIG.FOLDER_NAME);
  return it.hasNext() ? it.next() : DriveApp.createFolder(CONFIG.FOLDER_NAME);
}

function getOrCreate_(parent, name) {
  const it = parent.getFoldersByName(name);
  return it.hasNext() ? it.next() : parent.createFolder(name);
}

function safeEq_(a, b) {
  a = String(a || ""); b = String(b || "");
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

function out_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
